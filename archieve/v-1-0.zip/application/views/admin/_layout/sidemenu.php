<?php $modul = $this->uri->segment(2);
$method = $this->uri->segment(3);?>
