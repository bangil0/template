 <main>
    <center>
      <img class="responsive-img" style="width: 250px;" src="https://i.imgur.com/ax0NCsK.gif" />
      <div class="section"></div>

      <h5 class="indigo-text"><?=$title?></h5>
      <div class="section"></div>
      <?php if ($isi) $this->load->view($isi); ?>
    </center>
    <div class="section"></div>
    <div class="section"></div>
</main>
