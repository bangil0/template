        <!-- js for specified page -->
        <?php if ($js) $this->load->view($js); ?>
        </body>
</html>